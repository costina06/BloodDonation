package com.example.blooddonationapp.Email;

public class Util {
    // Add your own email and password over here.
    public  static  final String EMAIL = "blooddonationmobileapp@gmail.com";
    public static final String PASSWORD = "blooddonationmobileapp2021";
}
